// index.js

'use strict';

const packageInfo = require('../package.json');
const csconfigInfo = require('../cdconfig.json');

const provider = {
  Model: require('./model'),
  disableIdParam: csconfigInfo.properties.disableIdParam,
  hosts: csconfigInfo.properties.hosts,
  name: csconfigInfo.name,
  type: csconfigInfo.type,
  version: packageInfo.version
};

// Export provider registration object
module.exports = provider;
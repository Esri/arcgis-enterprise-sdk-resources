// parse-tweet.js

'use strict';

const geocodeAddress = require('./geocode-address');

// Helper function to return substring between start and end string
function getStrBetween(str, start, end) {
  return str.split(start).pop().split(end)[0].trim();
}

// Parse tweet text and call geocoding module to return coordinate array
module.exports = async function (tweetText) {

  // parse tweet to get address fields
  // the street field is required
  // all the rest are optional
  let street = '';
  let city = '';
  let state = '';
  let zipCode = '';

  // Street field is required
  street = getStrBetween(tweetText, 'Street:', 'City');

  // City field is optional
  if (tweetText.includes('City:')) {
    city = getStrBetween(tweetText, 'City:', 'State');
  }

  // State field is optional
  if (tweetText.includes('State:')) {
    state = getStrBetween(tweetText, 'State:', 'Zip Code');
  }

  // Zip code field is optional
  if (tweetText.includes('Zip Code:')) {
    zipCode = tweetText.split('Zip Code:')[1].trim();
  }

  // Construct geocoding query string using address fields
  let geocodingQuery = street + ', ' + city + ', ' + state + ', ' + zipCode;
  console.log(`geocodingQuery=${geocodingQuery}`);

  return await geocodeAddress(geocodingQuery);
};
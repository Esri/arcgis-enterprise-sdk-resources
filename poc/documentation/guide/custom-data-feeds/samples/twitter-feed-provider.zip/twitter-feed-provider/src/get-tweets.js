// get-tweets.js

// The code in this file is adapted from the following source:
// https://github.com/twitterdev/Twitter-API-v2-sample-code/blob/main/User-Tweet-Timeline/user_tweets.js

'use strict';

const config = require('../config/default.json');
const needle = require('needle');

const getTweets = async function () {
  let userTweets = [];
  let params = {
    'expansions': 'author_id',
    'max_results': 100,
    'tweet.fields': 'created_at'
  };
  const options = {
    headers: {
      'User-Agent': 'v2UserTweetsJS',
      'authorization': `Bearer ${config.twitter.bearer_token}`
    }
  };
  let hasNextPage = true;
  let nextToken = null;
  while (hasNextPage) {
    let resp = await getPage(params, options, nextToken);
    if (resp?.meta?.result_count > 0) {
      if (resp.data) {
        userTweets.push.apply(userTweets, resp.data);
      }
      if (resp.meta.next_token) {
        nextToken = resp.meta.next_token;
      } else {
        hasNextPage = false;
      }
    } else {
      hasNextPage = false;
    }
  }
  return userTweets;
};

const getPage = async function (params, options, nextToken) {
  if (nextToken) {
    params.pagination_token = nextToken;
  }
  try {
    const url = `https://api.twitter.com/2/users/${config.twitter.user_id}/tweets`;
    const resp = await needle('get', url, params, options);
    if (resp.statusCode !== 200) {
      console.log(`${resp.statusCode} ${resp.statusMessage}:`);
      console.log(resp.body);
      return;
    }
    return resp.body;
  } catch (err) {
    console.log(`request failed: ${err}`);
  }
};

module.exports = getTweets;
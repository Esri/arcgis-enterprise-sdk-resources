// geocode-address.js

'use strict';

const config = require('../config/default.json');
const nodeGeocoder = require('node-geocoder');

// Create geocoder
const geocoder = nodeGeocoder({
  apiKey: config.opencage.api_key,
  provider: 'opencage'
});

module.exports = function (addr) {

  // I'm using JS Promises here for cleaner code quality
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Promise
  return new Promise(function (resolve, reject) {

    // Make request to geocoding API
    geocoder.geocode(addr).then(function (res) {

      // Return coord array of form [lon, lat]
      // Take API's highest-confidence geocoding result
      resolve([res[0].longitude, res[0].latitude]);
    }).catch((err) => reject(err));
  });
};
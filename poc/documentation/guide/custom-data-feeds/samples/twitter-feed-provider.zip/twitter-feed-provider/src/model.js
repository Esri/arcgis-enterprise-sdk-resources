// model.js

'use strict';

const parseTweet = require('./parse-tweet');
const getTweets = require('./get-tweets');

// model class definition
function Model (koop) {
  // empty class
}

Model.prototype.getData = async function (req, callback) {

  // Get the array of tweets
  let tweets = await getTweets();

  // loop through tweet array and construct feature array
  let featureArray = [];
  let i;
  for (i = 0; i < tweets.length; i += 1) {
    let tweet = tweets[i];

    // get coordinates from tweet text using geocoding
    let coords = await parseTweet(tweet.text);
    featureArray.push({
      properties: {
        author_id: tweet.author_id,
        created_at: tweet.created_at,

        // parse tweet to get the text field
        text: tweet.text.split('Text:').pop().split('Street')[0].trim(),
        id: tweet.id
      },
      type: 'Feature',
      geometry: {
        type: 'Point',
        coordinates: coords
      }
    });
  }

  // Construct the GeoJSON object using the feature array
  const geojson = {
    type: 'FeatureCollection',
    features: featureArray,

    // set layer name
    metadata: {
      name: 'tweets'
    }
  }

  // Return the complete GeoJSON object
  callback(null, geojson)
}

// Export the model class
module.exports = Model;